/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2013 - 2018  SEGGER Microcontroller GmbH                 *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
*                                                                    *
*       emModbus * Modbus stack for embedded applications            *
*                                                                    *
*                                                                    *
*       Please note:                                                 *
*                                                                    *
*       Knowledge of this file may under no circumstances            *
*       be used to write a similar product for in-house use.         *
*                                                                    *
*       Thank you for your fairness !                                *
*                                                                    *
**********************************************************************
*                                                                    *
*       emModbus version: V1.02h                                     *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : Modbus_Slave_IFace.h
Purpose : Global types etc & general purpose utility functions
---------------------------END-OF-HEADER------------------------------
*/

#ifndef MODBUS_SLAVE_IFACE_H            // Guard against multiple inclusion
#define MODBUS_SLAVE_IFACE_H

#include "Global.h"         // Type definitions: U8, U16, U32, I8, I16, I32
#include "MB.h"

#if defined(__cplusplus)
extern "C" {     /* Make sure we have C-declarations in C++ programs */
#endif

/*********************************************************************
*
*       Variables
*
**********************************************************************
*/

extern const MB_IFACE_UART_API _IFaceRTU;
extern const MB_IFACE_UART_API _IFaceASCII;
extern const MB_IFACE_IP_API   _IFaceTCP;

extern       U8                _ConnectCnt;
extern       MB_CHANNEL        _MBChannel;

#if defined(__cplusplus)
}                /* Make sure we have C-declarations in C++ programs */
#endif

#endif                      // Avoid multiple inclusion

/*************************** End of file ****************************/
